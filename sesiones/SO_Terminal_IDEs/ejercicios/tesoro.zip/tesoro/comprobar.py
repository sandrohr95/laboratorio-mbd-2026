"""Comprueba tu respuesta a la búsqueda del tesoro.  Uso:  python comprobar.py"""
import hashlib
from pathlib import Path

HUELLA = "1e65a4c945b47e6d4dfb7fb7e4b7cbaf752cef77807d163826067541225101ed"
aqui = Path(__file__).resolve().parent
fichero = aqui / "entrega" / "respuesta.txt"

if not fichero.exists():
    raise SystemExit("No encuentro entrega/respuesta.txt. ¿Has creado la carpeta y el archivo?")

bruto = fichero.read_bytes()
# PowerShell 5 guarda con `>` en UTF-16; lo aceptamos igualmente.
texto = bruto.decode("utf-16") if bruto[:2] in (b"\xff\xfe", b"\xfe\xff") else bruto.decode("utf-8-sig")
respuesta = texto.strip().strip('"').strip().lower()

if hashlib.sha256(respuesta.encode()).hexdigest() == HUELLA:
    print("¡Tesoro encontrado! Respuesta correcta.")
    if (aqui / "trampa").exists():
        print("   …pero te falta borrar la carpeta `trampa` (rm -r trampa).")
else:
    partes = respuesta.split("-")
    print(f"Respuesta incorrecta: {respuesta!r}")
    if len(partes) != 5:
        print(f"   Formato: 5 partes separadas por guiones. Tu respuesta tiene {len(partes)}.")
    else:
        print("   El formato es correcto; revisa algún fragmento o el número.")
