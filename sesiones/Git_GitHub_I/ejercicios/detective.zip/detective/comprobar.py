"""Comprueba el ejercicio «Detective de Git».  Uso: python comprobar.py"""
import hashlib
import importlib.util
import subprocess
from pathlib import Path

HUELLAS = {1: '4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8', 2: 'e71d025a0b49b7d6c7d2d0a8af9ff4cb0079d2797feb9be286fd0fe5d24e935a', 3: '6bb37fcd2277b50b1fd0e7d1815d973ad387b42751c7bbd97313ef8cbd9cdbd9', 4: '9492b87272963a792fe89cd861045bde495d049a6bf9dc9f760f4dfd05f880c5', 5: '486b999fd66540d29e156b4b76b58f29e86188b173a005bbfcd4e1d77c0649af'}
AQUI = Path(__file__).resolve().parent
PROYECTO = AQUI / "proyecto"


def normalizar(texto):
    return " ".join(texto.strip().strip('"').strip("'").lower().split())


def git(*args):
    r = subprocess.run(["git", *args], cwd=PROYECTO, capture_output=True, text=True, encoding="utf-8")
    return r.returncode, r.stdout.strip()


def cargar(nombre):
    spec = importlib.util.spec_from_file_location(nombre, PROYECTO / f"{nombre}.py")
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


def parte_a():
    print("Parte A · Investiga la historia")
    fichero = AQUI / "respuestas.txt"
    bruto = fichero.read_bytes() if fichero.exists() else b""
    texto = bruto.decode("utf-16") if bruto[:2] in (b"\xff\xfe", b"\xfe\xff") else bruto.decode("utf-8-sig")
    respuestas = {}
    for linea in texto.splitlines():
        numero, _, valor = linea.partition(":")
        if numero.strip().isdigit():
            respuestas[int(numero)] = normalizar(valor)
    aciertos = 0
    for n, huella in HUELLAS.items():
        r = respuestas.get(n, "")
        ok = bool(r) and hashlib.sha256(r.encode()).hexdigest() == huella
        aciertos += ok
        print(f"  Pregunta {n}: {'correcta' if ok else ('sin responder' if not r else 'incorrecta')}")
    return aciertos == len(HUELLAS)


def comprobar(descripcion, condicion):
    print(f"  [{'OK' if condicion else '  '}] {descripcion}")
    return condicion


def parte_b():
    print("\nParte B · Arregla el proyecto")
    resultados = []
    _, rama = git("branch", "--show-current")
    resultados.append(comprobar("Estás en la rama main", rama == "main"))

    try:
        media_ok = cargar("estadisticas").media([2, 4, 6]) == 4.0
    except Exception:
        media_ok = False
    resultados.append(comprobar("media([2, 4, 6]) devuelve 4.0", media_ok))

    codigo, _ = git("ls-files", "--error-unmatch", "datos/ventas.csv")
    contenido = (PROYECTO / "datos" / "ventas.csv")
    recuperado = codigo == 0 and contenido.exists() and "clave:" in contenido.read_text(encoding="utf-8")
    resultados.append(comprobar("datos/ventas.csv está recuperado y guardado en un commit", recuperado))

    try:
        percentil_ok = cargar("percentiles").percentil([1, 2, 3, 4, 5], 50) == 3
    except Exception:
        percentil_ok = False
    _, fusiones = git("rev-list", "--merges", "--count", "main")
    resultados.append(comprobar("La rama pendiente está fusionada en main",
                                percentil_ok and fusiones.isdigit() and int(fusiones) >= 2))

    marcas = any("<<<<<<<" in f.read_text(encoding="utf-8") or ">>>>>>>" in f.read_text(encoding="utf-8")
                 for f in PROYECTO.glob("*.py"))
    comentario = "número de elementos" in (PROYECTO / "estadisticas.py").read_text(encoding="utf-8")
    resultados.append(comprobar("Conflicto resuelto sin marcas y conservando el comentario", not marcas and comentario))

    _, pendiente = git("status", "--porcelain")
    resultados.append(comprobar("git status: no hay cambios sin guardar en un commit", pendiente == ""))
    return all(resultados)


if __name__ == "__main__":
    a = parte_a()
    b = parte_b()
    print()
    if a and b:
        print("Caso resuelto. Enhorabuena, detective.")
    else:
        print("Aún quedan pistas por seguir. Revisa lo que no está marcado.")
