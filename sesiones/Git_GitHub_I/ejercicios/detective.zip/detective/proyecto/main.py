"""Ejemplo de uso del proyecto."""
from estadisticas import media, mediana

ventas = [120, 95, 143, 110, 160, 98]
print("Media:", media(ventas))
print("Mediana:", mediana(ventas))
