"""Gráficos de texto para la terminal."""


def barras(etiquetas, valores, ancho=40):
    """Dibuja un gráfico de barras horizontal con caracteres."""
    maximo = max(valores)
    for etiqueta, valor in zip(etiquetas, valores):
        largo = round(valor / maximo * ancho)
        print(f"{etiqueta:>10} | {'#' * largo} {valor}")
