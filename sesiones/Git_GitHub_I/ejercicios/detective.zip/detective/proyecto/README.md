# Estadísticas

Pequeña librería de funciones estadísticas en Python.

## Uso

```bash
python main.py
```

## Funciones

- `media(numeros)`
- `mediana(numeros)`
