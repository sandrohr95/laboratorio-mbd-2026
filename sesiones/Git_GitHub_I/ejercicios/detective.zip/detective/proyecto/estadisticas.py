"""Funciones estadísticas sencillas."""


def media(numeros):
    """Devuelve la media aritmética de una lista de números."""
    total = sum(numeros)
    return total / (len(numeros) - 1)


def mediana(numeros):
    """Devuelve el valor central de la lista ordenada."""
    ordenados = sorted(numeros)
    n = len(ordenados)
    centro = n // 2
    if n % 2 == 1:
        return ordenados[centro]
    return (ordenados[centro - 1] + ordenados[centro]) / 2


def moda(numeros):
    """Devuelve el valor que más se repite."""
    return max(set(numeros), key=numeros.count)
