# Detective de Git

En la carpeta `proyecto` hay una pequeña librería de estadística con su historial de Git. Tres personas han trabajado en ella y algo ha ido mal: la función `media()` da resultados incorrectos.

Trabaja **siempre desde la terminal**, dentro de la carpeta `proyecto`.

## Parte A · Investiga la historia

**Antes de cambiar nada**, responde a estas preguntas. Escribe cada respuesta en `respuestas.txt` (está junto a esta guía, fuera de `proyecto`), detrás del número correspondiente.

1. ¿Cuántos commits tiene la rama `main`?
2. ¿Quién escribió la función `mediana`? (nombre y apellido)
3. Alguien borró el archivo `datos/ventas.csv`. ¿Qué palabra aparece detrás de `clave:` en su primera línea?
4. ¿Qué día se introdujo el error en la función `media`? (formato `AAAA-MM-DD`)
5. Hay una rama que todavía no se ha fusionado en `main`. ¿Cómo se llama la función nueva que añade?

Comandos que te ayudarán: `git log` (prueba `--oneline`, `--graph`, `--all`, `-p`, `-S "texto"` y `-- ruta`), `git show`, `git diff`, `git blame` y `git branch -a`.

## Parte B · Arregla el proyecto

Ahora sí, haz cambios. Trabaja en la rama `main`.

1. **Corrige el error** de `media()` en `estadisticas.py` y haz un commit con un mensaje que explique el cambio.
2. **Recupera** `datos/ventas.csv` tal como estaba antes de borrarse y haz un commit. Pista: `git restore --source <commit> -- datos/ventas.csv`, donde `<commit>` es uno en el que el archivo todavía existía.
3. **Fusiona** la rama pendiente en `main` con `git merge`. Habrá un **conflicto**: resuélvelo conservando tu corrección **y** el comentario que añadió la otra rama. Después, termina la fusión con `git add` y `git commit`.

Al terminar, `git status` debe decir que no hay nada pendiente (*nothing to commit, working tree clean*).

## Comprobación

Desde la carpeta `detective` (no desde `proyecto`):

```bash
python3 comprobar.py     # en Windows: python comprobar.py
```
